const http = require('http');
const fs = require('fs');
const portfinder = require('portfinder');
const readline = require('readline');
const { encrypt, decrypt } = require('./epicSSO');
const { URLSearchParams, URL } = require('url');

process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;

let webServerPort = 1024;

// Secret for AES encryption, shared between Epic and our PACS.
let sharedSecret = '';

/**
 * Reads shared secret from console input.
 * @returns a promise.
 */
function readSharedSecret() {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  return new Promise(resolve => {
    console.log('Create viewer URL from My Facility -> Integration -> Viewer. Then edit and copy.');

    const readOnce = function () {
      rl.question('>>>> What is the shared secret? ', text => {
        if (text) {
          sharedSecret = text;
          resolve();
        } else {
          console.log('Error: Shared secret cannot be empty. Try again.');
          readOnce();
        }
      });
    };

    readOnce();
  });
}

/**
 * Returns a function to respond with a status code and a text.
 * @param {http.ServerResponse} res
 */
function getTextRespondFunc(res) {
  return (code, text) => {
    if (code >= 400) {
      res.writeHead(code, text);
      res.end();
    } else {
      res.writeHead(code, {
        'Content-Length': text.length,
        'Content-Type': 'application/json; charset=utf-8',
      });
      res.write(text, () => {
        res.end();
      });
    }
  };
}

/**
 * Handles a request to encrypt a URL
 * @param {http.IncomingMessage} req 
 * @param {http.ServerResponse} res 
 */
function handleEncryptionRequest(req, res) {
  const { viewerurl, epicuserid, userfirstname, userlastname, mrn, accessionnumber } = req.headers;
  const respond = getTextRespondFunc(res);

  if (!sharedSecret) {
    respond(503, 'Shared secret missing. Please enter shared secret on the server console.');
    return;
  }
  if (!viewerurl) {
    respond(400, 'Guest Viewer URL is missing.');
    return;
  }
  if (!mrn && !accessionnumber) {
    respond(400, 'Patient ID (MRN) is missing.');
    return;
  }

  const param = new URLSearchParams();
  const append = function (key, value) {
    if (key && value) {
      param.append(key, value);
    }
  }
  append('epicUserId', epicuserid);
  append('userFirstName', userfirstname);
  append('userLastName', userlastname);
  append('mrn', mrn);
  append('accessionNumber', accessionnumber);

  const encrypted = encrypt(param.toString(), sharedSecret);
  const url = new URL(viewerurl);
  url.searchParams.append('data', encrypted);
  const result = {
    searchParams: param.toString(),
    encryptedURL: url.toString(),
    encryptedSearchParams: encrypted.toString(),
  };
  respond(200, JSON.stringify(result, null, 2));
}

function handleDecryptionRequest(req, res) {
  const { encrypteddata:encryptedData } = req.headers;
  const respond = getTextRespondFunc(res);
  if (!sharedSecret) {
    respond(503, 'Shared secret missing. Please enter shared secret on the server console.');
    return;
  }
  if (!encryptedData) {
    respond(400, 'Encrypted URL is missing.');
    return;
  }
  try{
    const encryptedURL = new URL(encryptedData);
    const searchParams = encryptedURL.searchParams.get('data');
    const decrypted = decrypt(searchParams, sharedSecret);
    respond(200, JSON.stringify(decrypted, null, 2));
  }
  catch(error){
    console.log(error);
    respond(500, 'Unable to decrypt data');
    return;
  }

}
/**
 * Returns a function to respond with a file.
 * @param {http.ServerResponse} res 
 */
function getFileRespondFunc(res) {
  return (fileName, contentType) => {
    res.writeHead(200, {'Content-Type': contentType});
    const content = fs.readFileSync(fileName);
    res.write(content);
    res.end();
  };
}

let server;

/**
 * Creates a HTTP server.
 * @returns a promise.
 */
function createServer() {
  server = http.createServer(function (req, res) {
    const respondWithFile = getFileRespondFunc(res);

    switch (req.url) {
      case '/':
        respondWithFile('./index.html', 'text/html');
        break;
  
      case '/index.css':
        respondWithFile('./index.css', 'text/html');
        break;
  
      case '/index.js':
        respondWithFile('./index.js', 'text/javascript');
        break;
  
      case '/api/encrypt':
        handleEncryptionRequest(req, res);
        break;

      case '/api/decrypt':
        handleDecryptionRequest(req, res);  
  
      default:
        break;
    }
  });

  return new Promise((resolve, reject) => {
    portfinder.getPort({ port: webServerPort }, function (err, port) {
      if (!port) {
        reject('Error: No port available.');
        return;
      }
      webServerPort = port;
      server.listen(port);
      console.log('--------------------------------');
      console.log('Open Epic HTTP GET SSO Launchpad');
      console.log(`Running at: http://localhost:${webServerPort}`);
      console.log('');
      resolve();
    });    
  });
}

function start() {
  try {
    createServer().then(() => {
      readSharedSecret().then(() => {
        console.log(`Ready to launch viewer from page: http://localhost:${webServerPort}`);
      });
    });
  } catch (reason) {
    console.error(reason);
  }
}

start();
