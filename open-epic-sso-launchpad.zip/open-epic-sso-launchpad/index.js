function loadConfig() {
  const storage = window.localStorage;
  return {
    viewerUrl: storage.getItem('viewerUrl') || '',
    epicUserId: storage.getItem('epicUserId') || '',
    userFirstName: storage.getItem('userFirstName') || '',
    userLastName: storage.getItem('userLastName') || '',
    mrn: storage.getItem('mrn') || '',
    accessionNumber: storage.getItem('accessionNumber') || '',
    encryptedData: storage.getItem('encryptedData') || '',
  };
}

function saveConfig(param) {
  const { viewerUrl, epicUserId, userFirstName, userLastName, mrn, accessionNumber, encryptedData } = param;
  const storage = window.localStorage;
  storage.setItem('viewerUrl', viewerUrl ?? '');
  storage.setItem('epicUserId', epicUserId ?? '');
  storage.setItem('userFirstName', userFirstName ?? '');
  storage.setItem('userLastName', userLastName ?? '');
  storage.setItem('mrn', mrn ?? '');
  storage.setItem('accessionNumber', accessionNumber ?? '');
  storage.setItem('encryptedData', encryptedData ?? '');
}

function showErrorMessage(text) {
  const element = document.getElementById('error-message');
  element.innerHTML = text;
}

function showLaunchURL(text) {
  const element = document.getElementById('launch-url');
  element.innerHTML = text;
}

function showErrorMessageForDecryption(text) {
  const element = document.getElementById('decrypt-error-message');
  element.innerHTML = text;
}

function showDecryptedData(text) {
  const element = document.getElementById('url-params');
  element.innerHTML = text;
}

function collectParameters() {
  const viewerUrl = $('#viewer-url').val();
  const epicUserId = $('#epic-user-id').val();
  const userFirstName = $('#user-first-name').val();
  const userLastName = $('#user-last-name').val();
  const mrn = $('#patient-id').val();
  const accessionNumber = $('#accession-number').val();
  const encryptedData = $('#encrypted-url').val();

  return {
    viewerUrl,
    epicUserId,
    userFirstName,
    userLastName,
    mrn,
    accessionNumber,
    encryptedData,
  }
}

const setReqHeader = function (xhttp, key, value) {
  if (key && value) {
    xhttp.setRequestHeader(key, value);
  }
}

function encrypt(param) {
  const { viewerUrl, epicUserId, userFirstName, userLastName, mrn, accessionNumber } = param;

  return new Promise((resolve, reject) => {
    const xhttp = new XMLHttpRequest();
    xhttp.open('GET', '/api/encrypt');
    xhttp.onreadystatechange = function () {
      if (this.status === 200) {
        if (xhttp.responseText) {
          resolve (xhttp.responseText);
        }
      } else {
        reject(`Error ${this.status}: ${this.statusText}`);
      }
    };

    setReqHeader(xhttp, 'content-type', 'application/json; charset=utf-8');
    setReqHeader(xhttp, 'accept', 'application/json');
    setReqHeader(xhttp, 'viewerurl', viewerUrl);
    setReqHeader(xhttp, 'epicuserid', epicUserId);
    setReqHeader(xhttp, 'userfirstname', userFirstName);
    setReqHeader(xhttp, 'userlastname', userLastName);
    setReqHeader(xhttp, 'mrn', mrn);
    setReqHeader(xhttp, 'accessionnumber', accessionNumber);

    xhttp.send();
  });
}

function decrypt(param) {
  const { encryptedData } = param;

  return new Promise((resolve, reject) => {
    const xhttp = new XMLHttpRequest();
    xhttp.open('GET', '/api/decrypt');
    xhttp.onreadystatechange = function () {
      if (this.status === 200) {
        if (xhttp.responseText) {
          resolve (xhttp.responseText);
        }
      } else {
        reject(`Error ${this.status}: ${this.statusText}`);
      }
    };


    setReqHeader(xhttp, 'content-type', 'application/json; charset=utf-8');
    setReqHeader(xhttp, 'accept', 'application/json');
    setReqHeader(xhttp, 'encryptedData', encryptedData);
    xhttp.send();
  });
}

function collectAndLaunch() {
  const param = collectParameters();
  saveConfig(param);
  showErrorMessage('');
  showLaunchURL('');

  encrypt(param).then(resultText => {
    showLaunchURL(resultText);
    const { encryptedURL } = JSON.parse(resultText);
    if (encryptedURL) {
      window.open(encryptedURL, '_blank');
    }
  }).catch(reason => {
    showErrorMessage(reason);
  });
}

function decryptData() {
  const param = collectParameters();
  saveConfig(param);
  showDecryptedData('');
  showErrorMessageForDecryption('');
  decrypt(param).then(resultText =>{
    showDecryptedData(resultText);
  }).catch(reason =>{
    showErrorMessageForDecryption(reason);
  })
}

function initialize() {
  const { viewerUrl, epicUserId, userFirstName, userLastName, mrn, accessionNumber, encryptedData } = loadConfig();
  $('#viewer-url').val(viewerUrl);
  $('#epic-user-id').val(epicUserId);
  $('#user-first-name').val(userFirstName);
  $('#user-last-name').val(userLastName);
  $('#patient-id').val(mrn);
  $('#accession-number').val(accessionNumber);
  $('#encrypted-url').val(encryptedData);

  $('#launch-button').on('click', () => {
    collectAndLaunch();
  });
  $('#decrypt-button').on('click', ()=>{
    decryptData();
  })
};

initialize();
