var nexe = require('nexe');

nexe.compile({
    input: './server.js',
    output: './open-epic-sso-launchpad.exe',
    nodeVersion: '12.16.2',
    target: '12.16.2',
    nodeTempDir: __dirname,
    flags: true
  }, function(err) {
    if(err)console.log(err);
  }
);
