const crypto = require('crypto');
const xor = require('bitwise-xor');

// This file is copied from appServer/Packages/guest-viewer/lib/epicSSO.js
//
//
// See https://open.epic.com/launchpad/HttpGetSso
// Adapted from a Gist here: https://gist.github.com/emilyfeder/3ec62e86fa3aa1d4761f67c022f9fb72

const HASH_ALGORITHM = 'sha1';
const ALGORITHM = 'aes-128-cbc';
const UTF8 = 'utf8';
const BASE64 = 'base64';

// aes-128 requires a key of length 16
const KEY_LENGTH = 16;

// Epic uses an empty IV
const INITIALIZATION_VECTOR = Buffer.alloc(KEY_LENGTH);

function hash(input, encoding = 'utf8') {
  const hashed = crypto.createHash(HASH_ALGORITHM);
  hashed.update(input, encoding);
  return hashed.digest();
}

/**
 * This is the implementation of the Microsoft Key derivation algorithm, found here:
 * https://msdn.microsoft.com/en-us/library/windows/desktop/aa379916(v=vs.85).aspx#Remarks
 *
 * @param {String} secret A plaintext secret
 * @return {Buffer}
 */
function deriveKey(secret) {
  const secretHash = hash(secret, UTF8);
  const step1Mask = Buffer.alloc(secretHash.length, 0x36);
  const step1Buf = Buffer.concat([
    xor(step1Mask, secretHash),
    Buffer.alloc(64 - secretHash.length, 0x36)
  ]);
  const step1Result = hash(step1Buf.toString(BASE64), BASE64);
  const step2Mask = Buffer.alloc(secretHash.length, 0x5c);
  const step2Buf = Buffer.concat([
    xor(step2Mask, secretHash),
    Buffer.alloc(64 - secretHash.length, 0x5c)
  ]);
  const step2Result = hash(step2Buf.toString(BASE64), BASE64);
  const step3Result = Buffer.concat([step1Result, step2Result]);

  return step3Result.slice(0, KEY_LENGTH);
}

/**
 * Given a stringified dataset and a shared secret, return an encrypted string
 *
 * @param {String} data Stringified data to be encrypted
 * @param {String} secret The shared secret
 * @return {String} Encrypted result
 */
function encrypt(data, secret) {
  const key = deriveKey(secret);
  const cipher = crypto.createCipheriv(ALGORITHM, key, INITIALIZATION_VECTOR);
  cipher.setAutoPadding(true);
  return cipher.update(data, UTF8, BASE64) + cipher.final(BASE64);
}

/**
 * Given an encrypted string and a shared secret, return the decrypted contents
 *
 * @param {String} data Encrypted query parameters sent by open.epic, base64 encoded
 * @param {String} secret The shared secret
 * @return {String} Decrypted result
 */
function decrypt(data, secret) {
  const key = deriveKey(secret);
  const decipher = crypto.createDecipheriv(ALGORITHM, key, INITIALIZATION_VECTOR);

  // Configures PKCS7/PKCS5 padding
  decipher.setAutoPadding(true);
  return decipher.update(data, BASE64, UTF8) + decipher.final(UTF8);
}

module.exports = { encrypt, decrypt };
