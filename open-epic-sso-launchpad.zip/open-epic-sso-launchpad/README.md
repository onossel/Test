# open-epic-sso-launchpad
This program is an internal test tool to simulate Epic's https://open.epic.com/Launchpad/HttpGetSso


### System Requirement

|  Windows  |  MacOS  |
| ---- | ---- |
|  Chrome  |  Chrome  |
|    |  NodeJS  |

### Installation

#### Windows
1. Get this project by pushing `Download` button on this page or clone by git command.
   ```sh
   $ git clone https://gitlab.healthcareit.net/ei-nucleus/qe/vision-qe-tools.git
   ```
#### MacOS
1. Install NodeJS

   For first time, install NodeJS(https://nodejs.org/) on your environment.

2. Get this project by pushing `Download` button on this page or clone by git command.
   ```sh
   $ git clone https://gitlab.healthcareit.net/ei-nucleus/qe/vision-qe-tools.git
   ```

3. Install npm packages

   Go to extracted(cloned) folder and install npm packages by following command.
   ```sh
   $ cd open-epic-sso-launchpad
   $ npm install
   ```
### Run

|  Windows  |  MacOS  |
| ---- | ---- |
|  Double click `open-epic-sso-launchpad.exe`  |  $ node server.js  |

## Usage
1. Download the latest version from https://gitlab.healthcareit.net/ei-nucleus/qe/vision-qe-tools
1. On Windows, run "open-epic-sso-launchpad.exe" in its folder (other files must be there too).
1. It runs as a console application, and prompts to ask you for the shared secret.
1. If you have created a viewer URL from the PACS My Facility -> Integration -> Viewer, copy from there and paste.
1. Once shared secret is entered, you'll see "Ready to launch viewer from page" with a URL.
1. Open the URL in a web browser.
1. Copy and paste viewer URL. It is one of the 3 (Imaging Share viewer, Diagnostic viewer Desktop Client, or Diagnostic viewer).
1. Enter the Epic user ID (any string, but must match one you entered in your user profile) to launch as your user. Or leave it empty for guest access.
    - User first name and last name are optional.
    - To verify the user in the viewer, open dev console and type `Meteor.user()`.
1. Enter the Patient ID or MRN.
    - Accession number is optional and is only used to limit the search.
1. Press "Launch" button. The viewer shall launch.
    - An error message can be displayed above the Launch button.
    - The launch URL will be displayed below the Launch button.

 #### Decrypt
 1. After launching the Open Epic HTTP GET SSO Launchpad, Expand the Decrypt Data.
 1. Enter the encrypted URL.
 1. Press Decrypt URL button.
    - An error message can be displayed above the Launch button.  
    - The decrypted search params data will be displayed below the Launch button.

## On Mac OS
1. Node.js needs to be installed
1. Run command line "npm install" to install the "node_modules"
1. Run command line "npm start" to start the server. The rest is the same.

## Compile
On Windows, run command line "npm install" and then "npm run build". This will build into "open-epic-sso-launchpad.exe".
